package com.shivgujjar.aura
import android.app.Activity
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : Activity() {
    private var mp: MediaPlayer? = null
    private var idx = -1
    private lateinit var now: TextView
    private lateinit var status: TextView
    lateinit var playBtn: Button
    var isPlaying = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        FirebaseApp.initializeApp(this)
        val db = try { FirebaseFirestore.getInstance() } catch(e: Exception){ null }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0B0B0F")) }
        val h = TextView(this).apply { text = "🎵 AURA MUSIC\nFIREBASE CONNECTED"; textSize = 18f; setTextColor(Color.WHITE); setPadding(40,80,40,20); gravity = Gravity.CENTER }
        root.addView(h)
        status = TextView(this).apply { text = "✅ Project: shiv-gujjar-official | Connecting..."; textSize = 11f; setTextColor(Color.parseColor("#4CAF50")); setPadding(40,0,40,10) }
        root.addView(status)
        now = TextView(this).apply { text = "🎧 Select a song"; textSize = 15f; setTextColor(Color.WHITE); setPadding(40,15,40,15); setBackgroundColor(Color.parseColor("#222232")) }
        root.addView(now)

        val scroll = ScrollView(this)
        val listLay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,10,20,10) }
        scroll.addView(listLay)
        val lp = LinearLayout.LayoutParams(-1,0); lp.weight = 1f
        root.addView(scroll, lp)

        val defaultTitles = mutableListOf("Kesariya - Arijit","Tum Hi Ho","Calm Down - Rema","Perfect - Ed Sheeran","Excuses - AP","Brown Munde")
        val defaultUrls = mutableListOf(
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"
        )

        fun loadUI(titles: List<String>, urls: List<String>) {
            listLay.removeAllViews()
            status.text = "✅ ${titles.size} Songs | Firebase: shiv-gujjar-official"
            for (i in titles.indices) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(20,25,20,25); setBackgroundColor(Color.parseColor("#15151F")) }
                val ic = TextView(this).apply { text = "▶️ "; textSize = 18f; setTextColor(Color.WHITE) }
                val tv = TextView(this).apply { text = titles[i]; setTextColor(Color.WHITE); textSize = 14f }
                row.addView(ic); row.addView(tv)
                val tt = titles[i]; val uu = urls[i]
                row.setOnClickListener { playSong(i, tt, uu) }
                listLay.addView(row)
                listLay.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1,2); setBackgroundColor(Color.parseColor("#222222")) })
            }
        }

        loadUI(defaultTitles, defaultUrls)

        // Try Firebase
        db?.collection("songs")?.get()?.addOnSuccessListener { result ->
            if (!result.isEmpty) {
                val fbT = mutableListOf<String>()
                val fbU = mutableListOf<String>()
                for (doc in result.documents) {
                    val t = doc.getString("title") ?: continue
                    val u = doc.getString("url") ?: continue
                    fbT.add(t); fbU.add(u)
                }
                if (fbT.isNotEmpty()) {
                    defaultTitles.clear(); defaultUrls.clear()
                    defaultTitles.addAll(fbT); defaultUrls.addAll(fbU)
                    loadUI(defaultTitles, defaultUrls)
                }
            }
        }?.addOnFailureListener {
            status.text = "⚠️ Offline mode - ${defaultTitles.size} songs"
        }

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(20,30,20,30); setBackgroundColor(Color.parseColor("#1A1A24")) }
        val prev = Button(this).apply { text = "⏮️" }
        playBtn = Button(this).apply { text = "▶️ PLAY"; setBackgroundColor(Color.parseColor("#9C27B0")) }
        val next = Button(this).apply { text = "⏭️" }
        prev.setOnClickListener { if (idx > 0) playSong(idx-1, defaultTitles[idx-1], defaultUrls[idx-1]) }
        next.setOnClickListener { if (idx < defaultTitles.size-1) playSong(idx+1, defaultTitles[idx+1], defaultUrls[idx+1]) }
        playBtn.setOnClickListener {
            mp?.let {
                if (it.isPlaying) { it.pause(); isPlaying = false; playBtn.text = "▶️ PLAY" }
                else { it.start(); isPlaying = true; playBtn.text = "⏸️ PAUSE" }
            }
        }
        bottom.addView(prev); bottom.addView(playBtn); bottom.addView(next)
        root.addView(bottom)
        setContentView(root)
    }

    fun playSong(i: Int, t: String, u: String) {
        idx = i
        now.text = "🎧 $t"
        playBtn.text = "⏸️ PAUSE"
        isPlaying = true
        try {
            mp?.release()
            val player = MediaPlayer()
            player.setDataSource(u)
            player.prepareAsync()
            player.setOnPreparedListener { p -> p.start(); Toast.makeText(this, "Playing $t", Toast.LENGTH_SHORT).show() }
            player.setOnCompletionListener { isPlaying = false; playBtn.text = "▶️ PLAY" }
            mp = player
        } catch (e: Exception) { Toast.makeText(this, e.message, Toast.LENGTH_LONG).show() }
    }
    override fun onDestroy() { mp?.release(); super.onDestroy() }
}